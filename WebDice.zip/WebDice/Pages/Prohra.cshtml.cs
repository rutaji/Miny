using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebDice.Services;
using WebDice.Data;
using System.ComponentModel.DataAnnotations;

namespace WebDice.Pages
{
    public class ProhraModel : PageModel
    {
        DiceService DiceRoller { get; set; }

        public Dice dice { get; set; }
        public ProhraModel(DiceService diceRoller)
        {
            DiceRoller = diceRoller;
        }
        public void OnGet()
        {

            dice = DiceRoller.Roll();
        }
    }
}