﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebDice.Data;

namespace WebDice.Services
{
    public class DiceServicedsf
    {

        static readonly Random random = new Random();
        public Dice dice = new Dice();
       
        public Dice Roll()
        {
            
            return dice;
        }

    }
}
