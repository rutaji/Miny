﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebDice.Data;

namespace WebDice.Services
{
    public interface IServiceDiceProvider
    {
        Dice Roll();

    }
}
