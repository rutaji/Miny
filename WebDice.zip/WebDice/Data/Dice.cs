﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDice.Data
{
    public class Dice
    {
        public Mina[] pole = new Mina[500];
        int strana = 5;
        Random nahoda = new Random();
        public int[] zakaz = new int[10];
        public Dice()
        {       //beta možná použiju k nastavení rozměrů
            for(int i = 0;i != 10; i++)
            {
                zakaz[i] = (i+1) * strana;
            }

            //odsud důležité
            for (int i = 0; i != 25; i++)
            {
                pole[i] = new Mina();
            }
            for (int i = 4; i != 0; i--)
            {
                int a = nahoda.Next(0, strana * strana);
                //generuj minu
                if (!pole[a].bum)
                {
                    pole[a].bum = true;
                    if (a - 1 > 0 & a - 1 < 25 & !(zakaz.Contains(a))) { pole[a - 1].counter++; }
                    if (a + 1 > 0 & a + 1 < 25 & !(zakaz.Contains(a+1))) { pole[a + 1].counter++; }
                    if (a - strana > 0 & a - strana < 25) { pole[a - strana].counter++; }
                    if (a - 1 - strana > 0 & a - strana - 1 < 25 & !(zakaz.Contains(a))) { pole[a - strana - 1].counter++; }
                    if (a - strana + 1 > 0 & a - strana + 1 < 25 & !(zakaz.Contains(a+1))) { pole[a - strana + 1].counter++; }
                    if (a + strana > 0 & a + strana < 25) { pole[a + strana].counter++; }
                    if (a + strana - 1 > 0 & a + strana - 1 < 25 & !(zakaz.Contains(a))) { pole[a + strana - 1].counter++; }
                    if (a + strana + 1 > 0 & a + strana + 1 < 25 & !(zakaz.Contains(a+1))) { pole[a + strana + 1].counter++; }
                }
                else { i++; }
            }
        }
    }
}
