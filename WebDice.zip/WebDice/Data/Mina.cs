﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDice.Data
{
    public class Mina
    {
        public int counter;
        public bool bum;
        public bool viditelnost;
        public Mina()
        {
            counter = 0;
            bum = false;
            viditelnost = false;
        }
    }
}
